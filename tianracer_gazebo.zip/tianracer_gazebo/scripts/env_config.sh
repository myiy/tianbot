#! /bin/bash

# tkinter python3
sudo apt install python3-tk

# python pkg install
pip3 install -r requirements.txt

# font-dseg
sudo apt-get install fonts-dseg